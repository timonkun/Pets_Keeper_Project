// #define PATHSPCA "icons/"
#define PATHSPCA "/usr/local/share/spcagui/"
