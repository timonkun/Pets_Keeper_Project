 
 char version[] = "Spcaview version: 1.1.8 date: 25:12:2007 (C) mxhaard@magic.fr\0";
